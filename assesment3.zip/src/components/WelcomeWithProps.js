import React from "react";

const WelcomeWithProps = ({ user }) => <h2>Welcome, {user}!</h2>;

export default WelcomeWithProps;
