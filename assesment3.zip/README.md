# React User Management

This project demonstrates user login, registration, and state management using Props, Context, and Refs.
