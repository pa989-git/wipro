import React from "react";
import ReactDOM from "react-dom";
import StockDashboard from "./StockDashboard";

ReactDOM.render(<StockDashboard />, document.getElementById("root"));
