import React from "react";
const Third = () => <h3>Third Function Component</h3>;
export default Third;
