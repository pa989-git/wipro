import React from "react";
const Fourth = () => <h3>Fourth Function Component</h3>;
export default Fourth;
