import React, { Component } from "react";
class First1 extends Component {
    render() {
        return <h3>First Class Component</h3>;
    }
}
export default First1;
