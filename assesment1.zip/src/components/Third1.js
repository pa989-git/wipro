import React, { Component } from "react";
class Third1 extends Component {
    render() {
        return <h3>Third Class Component</h3>;
    }
}
export default Third1;
