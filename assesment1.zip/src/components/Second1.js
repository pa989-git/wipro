import React, { Component } from "react";
class Second1 extends Component {
    render() {
        return <h3>Second Class Component</h3>;
    }
}
export default Second1;
