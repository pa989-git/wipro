import React from "react";
const First = () => <h3>First Function Component</h3>;
export default First;
