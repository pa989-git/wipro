import React, { Component } from "react";
class Fourth1 extends Component {
    render() {
        return <h3>Fourth Class Component</h3>;
    }
}
export default Fourth1;
