import React from "react";
const Second = () => <h3>Second Function Component</h3>;
export default Second;
