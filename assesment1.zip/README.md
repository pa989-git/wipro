# React Hello World

This project contains multiple functional and class components and demonstrates passing props and handling events.
